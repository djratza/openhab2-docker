import RPi.GPIO as gpio
gpio.setmode(gpio.BCM)
gpio.setup(27, gpio.OUT)
gpio.output(27, gpio.LOW)
