<?php
if ($_GET['run']) {
  # This code will run if ?run=true is set.
  exec("/usr/bin/python /var/www/pi-heating-remote/rfoutlet/livolo3.py on");
  }
?>

<!-- This link will add ?run=true to your URL, myfilename.php?run=true -->
<a href="?run=true">Click Me!</a>


