<?php
if ($_GET['run']) {
  # This code will run if ?run=true is set.
  exec("/var/www/pi-heating-remote/rfoutlet/codesend -p 3 4543937");
  exec("/var/www/pi-heating-remote/rfoutlet/codesend -p 3 4527411");
}
?>

<!-- This link will add ?run=true to your URL, myfilename.php?run=true -->
<a href="?run=true">Click Me!</a>
