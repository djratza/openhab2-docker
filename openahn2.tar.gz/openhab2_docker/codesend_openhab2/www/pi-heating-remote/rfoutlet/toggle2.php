<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, must-revalidate');

// Edit these codes for each outlet
$codes = array(
    "1" => array(
        "on" => 4527411,
        "off" => 4527420
    ),
    "2" => array(
        "on" => 9868712,
        "off" => 9868708
    ),
    "3" => array(
        "on" => 4543937,
        "off" => 4543937
    ),
    "4" => array(
        "on" => 4543793,
        "off" => 4543793
    ),
    "5" => array(
        "on" => 357635,
        "off" => 357644
    ),
);

$codes2 = array(
	"4" => array(
	    "on" => 'livolo2.py on',
	    "off" => 'livolo2.py on
	),
);

// Path to the codesend binary (current directory is the default)
$codeSendPath = './codesend';

$codeSendPath2 = 'python';
// This PIN is not the first PIN on the Raspberry Pi GPIO header!
// Consult https://projects.drogon.net/raspberry-pi/wiringpi/pins/
// for more information.
$codeSendPIN = "1";

// Pulse length depends on the RF outlets you are using. Use RFSniffer to see what pulse length your device uses.
$codeSendPulseLength = "169";

if (!file_exists($codeSendPath)) {
    error_log("$codeSendPath is missing, please edit the script", 0);
    die(json_encode(array('success' => false)));
}

$outletLight = $_POST['outletId'];
$outletStatus = $_POST['outletStatus'];

if ($outletLight == "6") {
    // 6 is all 5 outlets combined
    if (function_exists('array_column')) {
        // PHP >= 5.5
        $codesToToggle = array_column($codes, $outletStatus);
    } else {
        $codesToToggle = array();
        foreach ($codes as $outletCodes) {
            array_push($codesToToggle, $outletCodes[$outletStatus]);
        }
    }
} else {
    // One
    $codesToToggle = array($codes[$outletLight][$outletStatus]);
}

$codesToToggle2 = array($codes2[$outletLight][$outletStatus]);

foreach ($codesToToggle2 as $codeSendCode2) {
   shell_exec($codeSendPath2 . ' ' . $codeSendCode2);
   sleep(1);

foreach ($codesToToggle as $codeSendCode) {
    shell_exec($codeSendPath . ' ' . $codeSendCode . ' -p ' . $codeSendPIN . ' -l ' . $codeSendPulseLength);
    sleep(1);
}

die(json_encode(array('success' => true)));
?>
